<template>
  <h1>PublishPost</h1>
</template>
