<template>
  <div class="card shadow-sm border-0 mb-4 bg-light">
    <div class="card-body p-4">
      
      <h5 class="fw-bold mb-2 d-flex align-items-center gap-2">
        <i class="bi bi-controller fs-4"></i> Jogo do Dia
      </h5>
      
      <p class="text-muted small mb-3">
        Quiz: Adivinhe o Período Geológico!
      </p>

      <button class="btn btn-secondary w-100 py-3 fw-bold text-uppercase shadow-sm">
        Jogar
      </button>

    </div>
  </div>
</template>

<style scoped>
.btn-secondary {
  background-color: #6c757d;
  border: none;
}
.btn-secondary:hover {
  background-color: #5a6268;
}
</style>