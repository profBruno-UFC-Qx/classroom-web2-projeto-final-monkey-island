<script setup lang="ts">
import AppNavbar from "./components/AppNavbar.vue";
</script>

<template>
  <AppNavbar />
  <router-view />
</template>

<style></style>
