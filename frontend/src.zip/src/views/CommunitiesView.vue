<template>
  <h1>Communities</h1>
</template>
